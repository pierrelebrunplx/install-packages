library(testthat)
library(flowClust)

test_check("flowClust")

#devtools::test("~/rglab/workspace/flowClust")

#taking quite some time , thus only for internal testing
#test_file("~/rglab/workspace/flowClust/tests/testthat/flowClust-gated-data.R")
#tools::checkDocFiles(dir = ".")
