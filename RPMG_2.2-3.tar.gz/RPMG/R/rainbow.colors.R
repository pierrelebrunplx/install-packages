 rainbow.colors<-function(n){ return( rainbow(n) ) }
