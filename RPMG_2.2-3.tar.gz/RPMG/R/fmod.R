`fmod` <-
function(k, m)
  {
    j = floor(k/m)
    a = k-m*j
    return(a)
  }

