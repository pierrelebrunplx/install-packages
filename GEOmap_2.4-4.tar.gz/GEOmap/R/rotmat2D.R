`rotmat2D` <-
function(alph)
{

matrix(c(cos(alph), -sin(alph), sin(alph), cos(alph)), ncol=2)

}

