`printGEOmap` <-
function(G)
  {

print( data.frame(G$STROKES) )




  }

