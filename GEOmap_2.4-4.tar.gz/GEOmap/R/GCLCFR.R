`GCLCFR` <-
function(t)
{
  r=sin(t)
  o=(1.0 - 0.0033670033 * (r*r))
  return(o)
}

