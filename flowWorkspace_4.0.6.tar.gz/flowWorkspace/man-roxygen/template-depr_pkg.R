#' @name flowWorkspace-deprecated
#' @description 
#' \code{<%= old %>} --> \code{<%= new %>}

