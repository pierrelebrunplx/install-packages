/*
Native API (dynamically generated via macros):
 
int anyMissing_internal(SEXP x, R_xlen_t *idxs, R_xlen_t nidxs)
*/

#include "anyMissing_lowlevel_template.h"
