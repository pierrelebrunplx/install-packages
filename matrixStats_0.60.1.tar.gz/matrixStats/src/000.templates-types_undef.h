#undef METHOD_NAME


#undef X_TYPE
#undef Y_TYPE
#undef ANS_TYPE

#undef MARGIN
#undef OP

