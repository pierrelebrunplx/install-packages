#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE "C++ Unit Tests for cytolib"
#include <boost/test/unit_test.hpp>

#include <cytolib/global.hpp>

using namespace cytolib;
