library("testthat")
test_check("aws.signature")
