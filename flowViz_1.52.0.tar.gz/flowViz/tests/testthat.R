library(testthat)
library(flowViz)

test_check("flowViz")
