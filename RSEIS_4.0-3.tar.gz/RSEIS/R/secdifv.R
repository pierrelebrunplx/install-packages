`secdifv` <-
function(T1, T2)
{
#  T1 and T2 are vectors

 return(secdif(T1[1], T1[2], T1[3], T1[4], T2[1], T2[2], T2[3], T2[4]  ))
}

