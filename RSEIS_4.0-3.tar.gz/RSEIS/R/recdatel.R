`recdatel` <-
function(X)
{
recdate(jd=X$jd, hr=X$hr, mi=X$mi, sec=X$sec, yr=X$yr)
}

