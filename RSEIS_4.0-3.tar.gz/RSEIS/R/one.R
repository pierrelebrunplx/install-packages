`one` <-
function()
  {
##X## plot using only one plot per page
    par(mfrow=c(1,1))

  }

