`envelope` <-
function(x)
  {
    
    h = hilbert(x)
    return(abs(h))

  }

