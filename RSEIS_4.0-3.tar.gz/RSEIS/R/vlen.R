`vlen` <-
function(A1)
  {
    return(sqrt(sum(A1^2)))
    
  }

