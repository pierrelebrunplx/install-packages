`JtimL` <-
function(j)
  {
    return(Jtim(j$jd, j$hr, j$mi, j$sec))
  }

