`JGRAY` <-
function(n)
  {
    RPMG::shade.col(n, acol=c(0,0,0))
  }

