/*****************************/
/* Global Variables          */
/*****************************/

double gasdev( long *idum );
void qcksrt( int n, double arr[] );
