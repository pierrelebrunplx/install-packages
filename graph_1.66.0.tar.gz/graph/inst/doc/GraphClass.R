### R code from vignette source 'GraphClass.Rnw'

###################################################
### code chunk number 1: graphClassDef
###################################################
library("graph")
getClass("graph")


###################################################
### code chunk number 2: multiGraphDef
###################################################
getClass("multiGraph")


