`TRANmat` <-
function(x,y,z)
  {
  r = diag(4)
    r[4, 1] = x
    r[4, 2] = y
    r[4, 3] = z
 return(r)

  }

