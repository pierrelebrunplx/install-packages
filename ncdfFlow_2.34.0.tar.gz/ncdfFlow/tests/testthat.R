library(testthat)
library(ncdfFlow)

test_check("ncdfFlow")
#devtools::test("~/rglab/workspace/ncdfFlow")
#test_file("~/rglab/workspace/ncdfFlow/inst/tests/test_ncdfFlowSet_accessor.R")
#test_file("~/rglab/workspace/ncdfFlow/inst/tests/test_ncdfFlowList.R")

