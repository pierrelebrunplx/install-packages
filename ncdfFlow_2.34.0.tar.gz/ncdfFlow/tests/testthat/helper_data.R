data(GvHD)
rectGate <- rectangleGate(filterId="nonDebris","FSC-H"=c(200,Inf))
