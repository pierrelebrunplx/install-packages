"inf.omit" <-
function(x) { 
  .Defunct("NaRV.omit", package="IDPmisc")
}

